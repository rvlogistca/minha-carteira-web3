const $ = (selector) => document.querySelector(selector);

const state = {
  address: null,
  connected: false,
  busy: false
};

const connectButton = $('#connectButton');
const refreshButton = $('#refreshButton');
const transactionsButton = $('#transactionsButton');
const copyAddressButton = $('#copyAddressButton');
const chainSelect = $('#chainSelect');

function showMessage(message, type = 'success') {
  const element = $('#message');
  element.textContent = message;
  element.className = `message visible ${type}`;
}

function clearMessage() {
  const element = $('#message');
  element.textContent = '';
  element.className = 'message';
}

function shortenAddress(address) {
  if (!address) return '—';
  return `${address.slice(0, 8)}…${address.slice(-6)}`;
}

function getChainId() {
  return chainSelect.value;
}

function formatNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return String(value ?? '—');
  return new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 8 }).format(number);
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
}

async function apiGet(path) {
  const response = await fetch(path, {
    method: 'GET',
    headers: { Accept: 'application/json' }
  });
  const data = await response.json();
  if (!response.ok || data.success === false) {
    throw new Error(data.error || 'Não foi possível consultar o servidor.');
  }
  return data;
}

function setConnected(address) {
  state.address = address;
  state.connected = Boolean(address);
  $('#connectionStatus').textContent = state.connected ? 'Conectada' : 'Desconectada';
  $('#walletState').textContent = state.connected ? 'Conectada' : 'Offline';
  $('#walletTitle').textContent = state.connected ? 'Carteira conectada' : 'Nenhuma carteira conectada';
  $('#walletAddress').textContent = state.connected ? address : 'Conecte uma carteira EVM compatível para começar.';
  connectButton.textContent = state.connected ? 'Carteira conectada' : 'Conectar carteira';
  copyAddressButton.disabled = !state.connected;
}

async function connectWallet() {
  clearMessage();
  if (!window.ethereum) {
    showMessage('Nenhuma carteira EVM foi detectada. Abra este site em um navegador com MetaMask ou outra carteira compatível.', 'error');
    return;
  }
  try {
    const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
    if (!accounts || !accounts.length) throw new Error('Nenhuma conta foi selecionada.');
    setConnected(accounts[0]);
    const chainHex = await window.ethereum.request({ method: 'eth_chainId' });
    const numericChain = parseInt(chainHex, 16);
    if ([1, 56, 137, 8453, 42161, 10].includes(numericChain)) {
      chainSelect.value = String(numericChain);
    }
    showMessage('Carteira conectada. A conexão permite consultar o endereço; as consultas à Binance são realizadas pelo backend.', 'success');
    await loadBalances();
  } catch (error) {
    showMessage(error.message || 'Não foi possível conectar a carteira.', 'error');
  }
}

async function loadBalances() {
  if (!state.address) {
    showMessage('Conecte sua carteira antes de consultar os saldos.', 'error');
    return;
  }
  if (state.busy) return;
  state.busy = true;
  refreshButton.disabled = true;
  refreshButton.textContent = 'Consultando…';
  $('#balanceBadge').textContent = 'Consultando';
  try {
    const params = new URLSearchParams({
      address: state.address,
      chainId: getChainId(),
      page: '1',
      pageSize: '100'
    });
    const result = await apiGet(`/api/balances?${params.toString()}`);
    const entries = Array.isArray(result.data?.data) ? result.data.data : [];
    const tokens = entries.flatMap(entry =>
      Array.isArray(entry.tokenAssets) ? entry.tokenAssets : []
    );
    renderBalances(tokens);
    $('#tokenCount').textContent = String(tokens.length);
    $('#lastUpdate').textContent = new Date().toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });
    $('#balanceBadge').textContent = `${tokens.length} token(s)`;
    showMessage('Consulta de saldos concluída.', 'success');
  } catch (error) {
    $('#balanceBadge').textContent = 'Falha na consulta';
    showMessage(error.message || 'Erro ao consultar os saldos.', 'error');
  } finally {
    state.busy = false;
    refreshButton.disabled = false;
    refreshButton.textContent = 'Atualizar painel';
  }
}

function renderBalances(tokens) {
  const container = $('#balanceContainer');
  if (!tokens.length) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">◇</div>
        <strong>Nenhum token retornado</strong>
        <p>A API não retornou tokens para este endereço e esta rede, ou não há ativos disponíveis.</p>
      </div>`;
    return;
  }
  const rows = tokens.map(token => `
    <tr>
      <td>
        <div class="token-name">
          <strong>${escapeHtml(token.symbol || 'Token')}</strong>
          <small>Rede ${escapeHtml(token.binanceChainId || getChainId())}</small>
        </div>
      </td>
      <td>${escapeHtml(formatNumber(token.balance))}</td>
      <td>${token.tokenPrice !== undefined && token.tokenPrice !== null
        ? escapeHtml(formatNumber(token.tokenPrice)) : '—'}</td>
      <td>${token.tokenContractAddress
        ? `<span class="address-short">${escapeHtml(shortenAddress(token.tokenContractAddress))}</span>`
        : 'Token nativo'}</td>
    </tr>`).join('');
  container.innerHTML = `
    <div class="table-wrap">
      <table><thead><tr><th>Ativo</th><th>Saldo</th><th>Preço retornado</th><th>Contrato</th></tr></thead><tbody>${rows}</tbody></table>
    </div>`;
}

async function loadTransactions() {
  if (!state.address) {
    showMessage('Conecte sua carteira antes de consultar as transações.', 'error');
    return;
  }
  transactionsButton.disabled = true;
  transactionsButton.textContent = 'Consultando…';
  const container = $('#transactionsContainer');
  container.innerHTML = `
    <div class="empty-state">
      <strong>Consultando histórico…</strong>
      <p>Aguarde enquanto buscamos as transações disponíveis.</p>
    </div>`;
  try {
    const params = new URLSearchParams({
      address: state.address,
      chainId: getChainId(),
      limit: '20'
    });
    const result = await apiGet(`/api/transactions?${params.toString()}`);
    const entries = Array.isArray(result.data?.data) ? result.data.data : [];
    const transactions = entries.flatMap(entry =>
      Array.isArray(entry.transactionList) ? entry.transactionList : []
    );
    renderTransactions(transactions);
    showMessage('Consulta do histórico concluída.', 'success');
  } catch (error) {
    container.innerHTML = `
      <div class="empty-state">
        <strong>Não foi possível carregar as transações</strong>
        <p>${escapeHtml(error.message)}</p>
      </div>`;
    showMessage(error.message || 'Erro ao consultar o histórico.', 'error');
  } finally {
    transactionsButton.disabled = false;
    transactionsButton.textContent = 'Consultar histórico';
  }
}

function renderTransactions(transactions) {
  const container = $('#transactionsContainer');
  if (!transactions.length) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">⇄</div>
        <strong>Nenhuma transação retornada</strong>
        <p>Não foram encontradas transações na consulta realizada.</p>
      </div>`;
    return;
  }
  const rows = transactions.map(tx => {
    const hash = tx.txHash || '';
    const status = tx.txStatus || 'Não informado';
    const time = tx.txTime ? new Date(Number(tx.txTime)).toLocaleString('pt-BR') : '—';
    const hashCell = /^0x[a-fA-F0-9]{64}$/.test(hash)
      ? `<button type="button" class="button button-secondary" data-tx-hash="${escapeHtml(hash)}">${escapeHtml(shortenAddress(hash))}</button>`
      : escapeHtml(hash || '—');
    return `
      <tr>
        <td>${hashCell}</td>
        <td>${escapeHtml(tx.symbol || '—')}</td>
        <td>${escapeHtml(formatNumber(tx.amount))}</td>
        <td>${escapeHtml(status)}</td>
        <td>${escapeHtml(time)}</td>
      </tr>`;
  }).join('');
  container.innerHTML = `
    <div class="table-wrap">
      <table><thead><tr><th>Hash</th><th>Ativo</th><th>Quantidade</th><th>Status</th><th>Data</th></tr></thead><tbody>${rows}</tbody></table>
    </div>`;
}

async function loadTransactionDetails(txHash) {
  const params = new URLSearchParams({ chainId: getChainId() });
  try {
    const result = await apiGet(`/api/transaction/${encodeURIComponent(txHash)}?${params}`);
    const formatted = JSON.stringify(result.data, null, 2);
    const dialog = document.createElement('dialog');
    dialog.className = 'transaction-dialog';
    const pre = document.createElement('pre');
    pre.textContent = formatted;
    const title = document.createElement('h3');
    title.textContent = 'Detalhes da transação';
    const closeButton = document.createElement('button');
    closeButton.type = 'button';
    closeButton.className = 'button button-primary';
    closeButton.textContent = 'Fechar';
    closeButton.addEventListener('click', () => { dialog.close(); dialog.remove(); });
    dialog.append(title, pre, closeButton);
    document.body.appendChild(dialog);
    dialog.showModal();
    dialog.addEventListener('close', () => { dialog.remove(); }, { once: true });
  } catch (error) {
    showMessage(error.message || 'Erro ao consultar detalhes da transação.', 'error');
  }
}

async function checkApiStatus() {
  const statusEl = $('#apiStatus');
  const dotEl = $('#apiStatusDot');
  try {
    const result = await apiGet('/api/health');
    statusEl.textContent = result.message || 'Online';
    if (dotEl) {
      dotEl.style.background = 'var(--green)';
      dotEl.style.boxShadow = '0 0 12px rgba(54, 229, 155, 0.35)';
    }
  } catch (error) {
    statusEl.textContent = 'Offline';
    if (dotEl) {
      dotEl.style.background = 'var(--danger)';
      dotEl.style.boxShadow = '0 0 12px rgba(255, 139, 139, 0.35)';
    }
  }
}

function copyAddress() {
  if (!state.address) return;
  navigator.clipboard.writeText(state.address)
    .then(() => showMessage('Endereço copiado para a área de transferência.', 'success'))
    .catch(() => showMessage('Não foi possível copiar o endereço.', 'error'));
}

function setupNavigation() {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
      item.classList.add('active');
    });
  });
}

function setupEventListeners() {
  connectButton.addEventListener('click', connectWallet);
  refreshButton.addEventListener('click', loadBalances);
  transactionsButton.addEventListener('click', loadTransactions);
  copyAddressButton.addEventListener('click', copyAddress);

  document.addEventListener('click', (event) => {
    const button = event.target.closest('[data-tx-hash]');
    if (button) {
      const hash = button.getAttribute('data-tx-hash');
      if (hash) loadTransactionDetails(hash);
    }
  });

  if (window.ethereum) {
    window.ethereum.on('accountsChanged', (accounts) => {
      if (accounts && accounts.length) {
        setConnected(accounts[0]);
        loadBalances();
      } else {
        setConnected(null);
      }
    });
    window.ethereum.on('chainChanged', () => {
      window.location.reload();
    });
  }
}

async function init() {
  setupNavigation();
  setupEventListeners();
  await checkApiStatus();

  if (window.ethereum) {
    try {
      const accounts = await window.ethereum.request({ method: 'eth_accounts' });
      if (accounts && accounts.length) {
        setConnected(accounts[0]);
        const chainHex = await window.ethereum.request({ method: 'eth_chainId' });
        const numericChain = parseInt(chainHex, 16);
        if ([1, 56, 137, 8453, 42161, 10].includes(numericChain)) {
          chainSelect.value = String(numericChain);
        }
      }
    } catch (_) {}
  }
}

document.addEventListener('DOMContentLoaded', init);
