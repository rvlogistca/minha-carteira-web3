import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';

const app = express();
const PORT = process.env.PORT || 3888;

const BINANCE_API_BASE = 'https://api.binance.com';
const BINANCE_API_KEY = process.env.BINANCE_API_KEY || '';
const BINANCE_API_SECRET = process.env.BINANCE_API_SECRET || '';

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: 'RV Web3 API está online',
    timestamp: new Date().toISOString(),
    apiConfigured: Boolean(BINANCE_API_KEY)
  });
});

app.get('/api/balances', async (req, res) => {
  try {
    const { address, chainId, page = 1, pageSize = 100 } = req.query;

    if (!address) {
      return res.status(400).json({
        success: false,
        error: 'Endereço da carteira é obrigatório'
      });
    }

    const mockData = {
      data: [
        {
          tokenAssets: [
            {
              symbol: 'ETH',
              name: 'Ethereum',
              balance: '1.25',
              tokenPrice: 3450.50,
              tokenContractAddress: null,
              binanceChainId: 1
            },
            {
              symbol: 'USDT',
              name: 'Tether USD',
              balance: '500.00',
              tokenPrice: 1.00,
              tokenContractAddress: '0xdac17f958d2ee523a2206206994597c13d831ec7',
              binanceChainId: 1
            },
            {
              symbol: 'BNB',
              name: 'BNB',
              balance: '15.5',
              tokenPrice: 580.25,
              tokenContractAddress: null,
              binanceChainId: 56
            }
          ]
        }
      ]
    };

    res.json({
      success: true,
      data: mockData
    });
  } catch (error) {
    console.error('Erro em /api/balances:', error);
    res.status(500).json({
      success: false,
      error: 'Erro ao consultar saldos'
    });
  }
});

app.get('/api/transactions', async (req, res) => {
  try {
    const { address, chainId, limit = 20 } = req.query;

    if (!address) {
      return res.status(400).json({
        success: false,
        error: 'Endereço da carteira é obrigatório'
      });
    }

    const mockData = {
      data: [
        {
          transactionList: [
            {
              txHash: '0x8f7d3b2a9c1e4f0d5c6b8a7e9f2d4c6a0b1e3f5d7c9b8a2e4f6c0d1a3b5e7f9',
              symbol: 'ETH',
              amount: '0.5',
              txStatus: 'Sucesso',
              txTime: String(Date.now() - 3600000)
            },
            {
              txHash: '0x2e4c6d8f0a1b3c5d7e9f1a2b4c6d8f0e2b4d6f8a1c3e5b7d9f1a3c5e7d9b1f4',
              symbol: 'USDT',
              amount: '150.00',
              txStatus: 'Sucesso',
              txTime: String(Date.now() - 86400000)
            }
          ]
        }
      ]
    };

    res.json({
      success: true,
      data: mockData
    });
  } catch (error) {
    console.error('Erro em /api/transactions:', error);
    res.status(500).json({
      success: false,
      error: 'Erro ao consultar transações'
    });
  }
});

app.get('/api/transaction/:hash', async (req, res) => {
  try {
    const { hash } = req.params;

    res.json({
      success: true,
      data: {
        txHash: hash,
        blockNumber: 19876543,
        from: '0x7a23d9e8c6f1b0a4d5e7c9b2f3a1d8e6c0b4a9d2',
        to: '0x1b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0c',
        value: '0.25 ETH',
        gasUsed: '21000',
        status: 'Sucesso',
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('Erro em /api/transaction/:hash:', error);
    res.status(500).json({
      success: false,
      error: 'Erro ao consultar detalhes da transação'
    });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 RV Web3 rodando na porta ${PORT}`);
  console.log(`📍 Acesse: http://localhost:${PORT}`);
});
